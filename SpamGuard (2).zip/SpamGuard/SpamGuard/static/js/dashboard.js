/* Dashboard: every number and chart is drawn from /api/stats (your saved scans). */
(function () {
  "use strict";
  var $ = function (id) { return document.getElementById(id); };

  function kpis(d) {
    SG.countUp($("k-total"), d.total);
    SG.countUp($("k-spam"), d.spam);
    SG.countUp($("k-ham"), d.ham);
    SG.countUp($("k-rate"), d.spam_rate, { dec: 1, suffix: "%" });
    SG.countUp($("k-avg"), d.avg_score, { dec: 1, suffix: "%" });
  }

  function niceMax(v) {
    if (v <= 4) return 4;
    var p = Math.pow(10, Math.floor(Math.log10(v))), n = v / p;
    return (n <= 2 ? 2 : n <= 5 ? 5 : 10) * p;
  }

  function timeline(data) {
    var host = $("chart-timeline"); host.replaceChildren();
    var W = 640, H = 230, L = 34, R = 8, T = 10, B = 28, iw = W - L - R, ih = H - T - B;
    var max = niceMax(Math.max.apply(null, data.map(function (x) { return x.total; }).concat([1])));
    var s = SG.svg("svg", { viewBox: "0 0 " + W + " " + H, "class": "svgchart", preserveAspectRatio: "xMidYMid meet" });
    for (var i = 0; i <= 4; i++) {
      var y = T + ih - (ih * i) / 4;
      s.appendChild(SG.svg("line", { "class": "grid", x1: L, x2: W - R, y1: y, y2: y }));
      var tl = SG.svg("text", { "class": "axis", x: L - 6, y: y + 3.5, "text-anchor": "end" }); tl.textContent = Math.round((max * i) / 4);
      s.appendChild(tl);
    }
    var step = iw / data.length, bw = Math.min(26, step * 0.62);
    data.forEach(function (x, idx) {
      var cx = L + step * idx + step / 2, h = (x.total / max) * ih, hs = (x.spam / max) * ih;
      var g = SG.svg("g", { "class": "bar-g" });
      var t = SG.svg("title"); t.textContent = x.date + ": " + x.total + " scan" + (x.total === 1 ? "" : "s") + ", " + x.spam + " spam";
      g.appendChild(t);
      g.appendChild(SG.svg("rect", { "class": "bar-total", x: cx - bw / 2, y: T + ih - h, width: bw, height: Math.max(h, x.total ? 2 : 0), rx: 4 }));
      if (x.spam) g.appendChild(SG.svg("rect", { "class": "bar-spam", x: cx - bw / 2, y: T + ih - hs, width: bw, height: Math.max(hs, 2), rx: 4 }));
      g.appendChild(SG.svg("rect", { "class": "hit", x: cx - step / 2, y: T, width: step, height: ih }));
      s.appendChild(g);
      if (idx % 2 === (data.length % 2 === 0 ? 1 : 0)) {
        var d = new Date(x.date + "T00:00:00Z");
        var lb = SG.svg("text", { "class": "axis", x: cx, y: H - 8, "text-anchor": "middle" });
        lb.textContent = d.toLocaleDateString(undefined, { month: "short", day: "numeric", timeZone: "UTC" });
        s.appendChild(lb);
      }
    });
    host.appendChild(s);
  }

  function donut(d) {
    var host = $("chart-donut"); host.replaceChildren();
    var r = 56, c = 2 * Math.PI * r, total = d.total || 1;
    var s = SG.svg("svg", { viewBox: "0 0 160 160", "class": "donut" });
    s.appendChild(SG.svg("circle", { "class": "d-ham", cx: 80, cy: 80, r: r, fill: "none", "stroke-width": 20 }));
    var spamLen = (d.spam / total) * c;
    var arc = SG.svg("circle", { "class": "d-spam", cx: 80, cy: 80, r: r, fill: "none", "stroke-width": 20, transform: "rotate(-90 80 80)" });
    arc.style.strokeDasharray = spamLen + " " + c;
    s.appendChild(arc);
    var n = SG.svg("text", { "class": "d-num", x: 80, y: 82, "text-anchor": "middle" }); n.textContent = d.spam_rate.toFixed(1) + "%";
    var l = SG.svg("text", { "class": "d-sub", x: 80, y: 100, "text-anchor": "middle" }); l.textContent = "spam rate";
    s.append(n, l);
    host.appendChild(s);
    var lg = SG.el("ul", "donut-legend");
    [["spam", "Spam", d.spam], ["ham", "Ham", d.ham]].forEach(function (r) {
      var li = SG.el("li"); li.append(SG.el("i", "dot dot-" + r[0]), SG.el("span", null, r[1]), SG.el("b", "mono", String(r[2])));
      lg.appendChild(li);
    });
    host.appendChild(lg);
  }

  function buckets(list) {
    var host = $("chart-buckets"); host.replaceChildren();
    var max = Math.max.apply(null, list.map(function (b) { return b.count; }).concat([1]));
    var box = SG.el("ul", "hbars");
    list.forEach(function (b, i) {
      var li = SG.el("li"), bar = SG.el("span", "hbar-track"), fill = SG.el("span", "hbar-fill band-" + i);
      fill.style.width = (b.count / max) * 100 + "%";
      bar.appendChild(fill);
      li.append(SG.el("span", "hbar-label mono", b.range), bar, SG.el("b", "mono", String(b.count)));
      box.appendChild(li);
    });
    host.appendChild(box);
  }

  function topTerms(list) {
    var host = $("top-terms"); host.replaceChildren();
    if (!list.length) { host.appendChild(SG.el("p", "muted small pad", "Spam verdicts will reveal their most common trigger words here.")); return; }
    var max = list[0].count, box = SG.el("ul", "hbars");
    list.forEach(function (t) {
      var li = SG.el("li"), bar = SG.el("span", "hbar-track"), fill = SG.el("span", "hbar-fill band-4");
      fill.style.width = (t.count / max) * 100 + "%";
      bar.appendChild(fill);
      li.append(SG.el("span", "hbar-label", t.word), bar, SG.el("b", "mono", String(t.count)));
      box.appendChild(li);
    });
    host.appendChild(box);
  }

  function recent(items, last) {
    var tb = $("recent-body"); tb.replaceChildren();
    if (!items.length) {
      var tr = SG.el("tr"), td = SG.el("td", "muted center", "No scans yet."); td.colSpan = 4; tr.appendChild(td); tb.appendChild(tr); return;
    }
    items.forEach(function (it) {
      var tr = SG.el("tr");
      var m = SG.el("td", "msg-cell"), t = it.subject || it.message;
      m.appendChild(SG.el("span", "msg-title", t.length > 80 ? t.slice(0, 80) + "…" : t));
      if (it.subject && it.message) m.appendChild(SG.el("span", "muted small msg-sub", it.message.length > 90 ? it.message.slice(0, 90) + "…" : it.message));
      var v = SG.el("td"); v.appendChild(SG.badge(it.label));
      var sc = SG.el("td"), w = SG.el("div", "score-cell"), tr2 = SG.el("span", "mini-track"), f = SG.el("span", "mini-fill " + it.label);
      f.style.width = Math.min(100, it.spam_score) + "%"; tr2.appendChild(f);
      w.append(SG.el("span", "mono", it.spam_score.toFixed(1) + "%"), tr2); sc.appendChild(w);
      var when = SG.el("td", "muted nowrap", SG.ago(it.created_at)); when.title = SG.fmtDateTime(it.created_at);
      tr.append(m, v, sc, when); tb.appendChild(tr);
    });
    if (last) $("last-scan").textContent = "Last scan " + SG.ago(last);
  }

  async function load() {
    try {
      var d = await SG.api("/api/stats");
      kpis(d);
      var none = d.total === 0;
      $("dash-empty").hidden = !none;
      $("dash-charts").hidden = none;
      $("recent-card").hidden = none;
      if (none) return;
      timeline(d.timeline); donut(d); buckets(d.score_buckets); topTerms(d.top_terms); recent(d.recent, d.last_scan);
    } catch (e) {
      var box = $("dash-error"); box.textContent = e.message; box.hidden = false;
    }
  }
  load();
})();
