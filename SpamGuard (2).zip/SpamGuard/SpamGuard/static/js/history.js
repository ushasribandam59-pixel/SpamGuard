/* History: server-side search / filter / pagination, delete, clear. */
(function () {
  "use strict";
  var $ = function (id) { return document.getElementById(id); };
  var state = { page: 1, label: "", q: "" }, pages = 1, timer = null;

  function row(it) {
    var tr = SG.el("tr", "h-row");
    var td = SG.el("td", "msg-cell");
    var title = it.subject || it.message;
    var btn = SG.el("button", "msg-toggle", ""); btn.type = "button"; btn.setAttribute("aria-expanded", "false");
    btn.appendChild(SG.el("span", "msg-title", title));
    var full = SG.el("div", "msg-full"); full.hidden = true;
    if (it.subject) full.appendChild(SG.el("p", "msg-subj", "Subject: " + it.subject));
    full.appendChild(SG.el("p", null, it.message));
    btn.addEventListener("click", function () {
      var open = full.hidden; full.hidden = !open; btn.setAttribute("aria-expanded", String(open)); tr.classList.toggle("open", open);
    });
    td.append(btn, full);
    var v = SG.el("td"); v.appendChild(SG.badge(it.label));
    var sc = SG.el("td"), w = SG.el("div", "score-cell"), t = SG.el("span", "mini-track"), f = SG.el("span", "mini-fill " + it.label);
    f.style.width = Math.min(100, it.spam_score) + "%"; t.appendChild(f);
    w.append(SG.el("span", "mono", it.spam_score.toFixed(1) + "%"), t); sc.appendChild(w);
    var when = SG.el("td", "muted nowrap", SG.fmtDateTime(it.created_at));
    var act = SG.el("td", "col-act");
    var del = SG.el("button", "icon-btn danger", ""); del.type = "button"; del.setAttribute("aria-label", "Delete this scan"); del.title = "Delete";
    del.appendChild(SG.icon("trash"));
    del.addEventListener("click", async function () {
      if (!confirm("Delete this scan from your history?")) return;
      try { await SG.api("/api/history/" + it.id, { method: "DELETE" }); SG.toast("Scan deleted."); load(); }
      catch (e) { SG.toast(e.message, "error"); }
    });
    act.appendChild(del);
    tr.append(td, v, sc, when, act);
    return tr;
  }

  async function load() {
    var qs = new URLSearchParams({ page: state.page, per_page: 10 });
    if (state.label) qs.set("label", state.label);
    if (state.q) qs.set("q", state.q);
    var err = $("h-error"); err.hidden = true;
    try {
      var d = await SG.api("/api/history?" + qs.toString());
      pages = d.pages;
      if (state.page > pages) { state.page = pages; return load(); }
      var tb = $("h-body"); tb.replaceChildren();
      d.items.forEach(function (it) { tb.appendChild(row(it)); });
      var none = d.items.length === 0, filtered = !!(state.label || state.q);
      $("h-empty").hidden = !none;
      document.querySelector(".table-history").hidden = none;
      $("h-empty-title").textContent = filtered ? "No matching scans" : "No scans yet";
      $("h-empty-text").textContent = filtered ? "Try a different search or filter." : "Scan a message and it will show up here.";
      $("h-pager").hidden = d.pages <= 1;
      $("h-page").textContent = "Page " + d.page + " of " + d.pages + " · " + d.total + " scans";
      $("h-prev").disabled = d.page <= 1; $("h-next").disabled = d.page >= d.pages;
    } catch (e) { err.textContent = e.message; err.hidden = false; }
  }

  $("h-q").addEventListener("input", function (e) {
    clearTimeout(timer);
    timer = setTimeout(function () { state.q = e.target.value.trim(); state.page = 1; load(); }, 250);
  });
  document.querySelectorAll(".seg-btn").forEach(function (b) {
    b.addEventListener("click", function () {
      document.querySelectorAll(".seg-btn").forEach(function (x) { x.classList.toggle("active", x === b); });
      state.label = b.getAttribute("data-label"); state.page = 1; load();
    });
  });
  $("h-prev").addEventListener("click", function () { if (state.page > 1) { state.page--; load(); } });
  $("h-next").addEventListener("click", function () { if (state.page < pages) { state.page++; load(); } });
  $("clear-all").addEventListener("click", async function () {
    if (!confirm("Delete ALL scans from your history? This cannot be undone.")) return;
    try { var r = await SG.api("/api/history", { method: "DELETE" }); SG.toast(r.deleted + " scan(s) deleted."); state.page = 1; load(); }
    catch (e) { SG.toast(e.message, "error"); }
  });
  load();
})();
