/* SpamGuard shared helpers: API, toasts, theme, nav, count-up, reveal. */
(function () {
  "use strict";
  var SG = (window.SG = {});
  var NS = "http://www.w3.org/2000/svg";

  SG.csrf = function () {
    var m = document.querySelector('meta[name="csrf-token"]');
    return m ? m.content : "";
  };

  SG.api = async function (url, opts) {
    opts = opts || {};
    var headers = Object.assign({ Accept: "application/json", "X-CSRF-Token": SG.csrf() }, opts.headers || {});
    var body = opts.body;
    if (body && typeof body !== "string") { headers["Content-Type"] = "application/json"; body = JSON.stringify(body); }
    var res;
    try {
      res = await fetch(url, { method: opts.method || "GET", headers: headers, body: body, credentials: "same-origin" });
    } catch (e) {
      throw new Error("Could not reach the server. Check that SpamGuard is running.");
    }
    var data = null;
    try { data = await res.json(); } catch (e) { /* non-JSON */ }
    if (!res.ok) throw new Error((data && data.error) || "Request failed (" + res.status + ").");
    return data;
  };

  SG.el = function (tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text != null) n.textContent = text;
    return n;
  };
  SG.svg = function (tag, attrs) {
    var n = document.createElementNS(NS, tag);
    for (var k in attrs || {}) n.setAttribute(k, attrs[k]);
    return n;
  };
  SG.icon = function (name, cls) {
    var s = SG.svg("svg", { "class": "ic " + (cls || ""), "aria-hidden": "true" });
    var u = SG.svg("use"); u.setAttribute("href", "#i-" + name); s.appendChild(u);
    return s;
  };

  SG.toast = function (msg, type) {
    var box = document.getElementById("toasts");
    if (!box) return;
    var t = SG.el("div", "toast toast-" + (type || "success"), msg);
    t.setAttribute("role", "status");
    box.appendChild(t);
    setTimeout(function () { t.classList.add("out"); setTimeout(function () { t.remove(); }, 300); }, 4200);
  };

  SG.parseDate = function (s) { return new Date(s); };
  SG.fmtDateTime = function (s) {
    var d = SG.parseDate(s);
    return isNaN(d) ? s : d.toLocaleString(undefined, { dateStyle: "medium", timeStyle: "short" });
  };
  SG.ago = function (s) {
    var d = SG.parseDate(s), sec = Math.round((Date.now() - d.getTime()) / 1000);
    if (isNaN(sec)) return s;
    if (sec < 45) return "just now";
    if (sec < 3600) return Math.round(sec / 60) + " min ago";
    if (sec < 86400) return Math.round(sec / 3600) + " h ago";
    if (sec < 7 * 86400) return Math.round(sec / 86400) + " d ago";
    return d.toLocaleDateString(undefined, { dateStyle: "medium" });
  };

  SG.countUp = function (node, to, opts) {
    opts = opts || {};
    var dec = opts.dec || 0, suffix = opts.suffix || "";
    var fmt = function (v) { return v.toLocaleString(undefined, { minimumFractionDigits: dec, maximumFractionDigits: dec }) + suffix; };
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches || to === 0) { node.textContent = fmt(to); return; }
    var start = performance.now(), dur = 900;
    (function tick(now) {
      var p = Math.min(1, (now - start) / dur), e = 1 - Math.pow(1 - p, 3);
      node.textContent = fmt(to * e);
      if (p < 1) requestAnimationFrame(tick);
    })(start);
  };

  SG.badge = function (label) {
    var b = SG.el("span", "badge badge-" + label, label === "spam" ? "SPAM" : "HAM");
    return b;
  };

  /* ---- theme toggle ---- */
  var tt = document.getElementById("theme-toggle");
  if (tt) tt.addEventListener("click", function () {
    var next = document.documentElement.getAttribute("data-theme") === "dark" ? "light" : "dark";
    document.documentElement.setAttribute("data-theme", next);
    try { localStorage.setItem("spamguard-theme", next); } catch (e) {}
    document.dispatchEvent(new CustomEvent("themechange"));
  });

  /* ---- mobile nav ---- */
  var nt = document.getElementById("nav-toggle"), links = document.getElementById("nav-links");
  if (nt && links) {
    var setOpen = function (open) {
      document.body.classList.toggle("nav-open", open);
      nt.setAttribute("aria-expanded", String(open));
      nt.setAttribute("aria-label", open ? "Close menu" : "Open menu");
    };
    nt.addEventListener("click", function () { setOpen(!document.body.classList.contains("nav-open")); });
    links.addEventListener("click", function (e) { if (e.target.closest("a")) setOpen(false); });
    document.addEventListener("keydown", function (e) { if (e.key === "Escape") setOpen(false); });
    window.addEventListener("resize", function () { if (window.innerWidth > 860) setOpen(false); });
  }

  /* ---- flash toasts auto-dismiss ---- */
  document.querySelectorAll("#toasts .toast").forEach(function (t, i) {
    setTimeout(function () { t.classList.add("out"); setTimeout(function () { t.remove(); }, 300); }, 5000 + i * 400);
  });

  /* ---- show/hide password ---- */
  document.querySelectorAll("[data-toggle-pw]").forEach(function (b) {
    b.addEventListener("click", function () {
      var inp = document.getElementById(b.getAttribute("data-toggle-pw"));
      if (!inp) return;
      var show = inp.type === "password";
      inp.type = show ? "text" : "password";
      b.setAttribute("aria-label", show ? "Hide password" : "Show password");
    });
  });

  /* ---- landing stats count-up + scroll reveal ---- */
  var io = "IntersectionObserver" in window ? new IntersectionObserver(function (entries) {
    entries.forEach(function (en) {
      if (!en.isIntersecting) return;
      var n = en.target;
      n.classList.add("in");
      if (n.hasAttribute("data-count")) {
        SG.countUp(n, parseFloat(n.getAttribute("data-count")), { dec: +n.getAttribute("data-dec") || 0, suffix: n.getAttribute("data-suffix") || "" });
      }
      io.unobserve(n);
    });
  }, { threshold: 0.15 }) : null;
  document.querySelectorAll(".reveal, [data-count]").forEach(function (n) {
    if (io) io.observe(n); else n.classList.add("in");
  });
})();
