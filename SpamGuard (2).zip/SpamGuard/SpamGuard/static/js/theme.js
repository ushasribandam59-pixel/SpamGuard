/* Runs in <head> before first paint to avoid a theme flash. */
(function () {
  var root = document.documentElement;
  root.classList.add("js");
  var t = null;
  try { t = localStorage.getItem("spamguard-theme"); } catch (e) {}
  if (t !== "light" && t !== "dark") {
    t = window.matchMedia && window.matchMedia("(prefers-color-scheme: light)").matches ? "light" : "dark";
  }
  root.setAttribute("data-theme", t);
})();
