/* Scanner: submits to /api/predict and renders the real model response. */
(function () {
  "use strict";
  var root = document.getElementById("scanner");
  if (!root) return;
  var $ = function (id) { return document.getElementById(id); };
  var form = $("spam-form"), subject = $("subject"), message = $("message"),
      count = $("char-count"), btn = $("check-button"), card = $("result-card"),
      empty = $("result-empty"), body = $("result-body");
  var maxMsg = +root.getAttribute("data-max-message") || 5000;

  var SAMPLES = {
    spam: { subject: "Congratulations! You won a prize", message: "WINNER!! You have won a free £1000 gift voucher. Call now on 09061701461 or visit www.claim-prize.com to claim your cash prize. Urgent - offer expires today!" },
    ham: { subject: "Python assignment submission", message: "Hi, please submit your Python assignment before Monday. We will discuss the project in our next class. Let me know if you have any questions." }
  };

  function updateCount() { count.textContent = message.value.length + " / " + maxMsg; }
  message.addEventListener("input", updateCount);
  updateCount();

  function fill(kind) { subject.value = SAMPLES[kind].subject; message.value = SAMPLES[kind].message; updateCount(); message.focus(); }
  $("spam-sample").addEventListener("click", function () { fill("spam"); });
  $("ham-sample").addEventListener("click", function () { fill("ham"); });
  $("clear-form").addEventListener("click", function () {
    subject.value = ""; message.value = ""; updateCount();
    body.hidden = true; body.replaceChildren(); empty.hidden = false; card.setAttribute("data-state", "idle");
    message.focus();
  });

  function setBusy(busy) {
    btn.disabled = busy;
    btn.querySelector(".btn-label").textContent = busy ? "Analyzing…" : "Scan for spam";
    btn.classList.toggle("loading", busy);
  }

  function showError(msg) {
    empty.hidden = true; body.hidden = false; body.replaceChildren();
    card.setAttribute("data-state", "error");
    var box = SG.el("div", "result-error");
    box.append(SG.icon("bang", "lg-ic"), SG.el("h3", "h3", "Unable to analyze"), SG.el("p", "muted", msg));
    body.appendChild(box);
  }

  function gauge(score, state) {
    var r = 52, c = 2 * Math.PI * r;
    var s = SG.svg("svg", { "class": "gauge", viewBox: "0 0 120 120", role: "img", "aria-label": "Spam score " + score.toFixed(1) + " percent" });
    s.appendChild(SG.svg("circle", { "class": "g-track", cx: 60, cy: 60, r: r, fill: "none", "stroke-width": 9 }));
    var arc = SG.svg("circle", { "class": "g-arc", cx: 60, cy: 60, r: r, fill: "none", "stroke-width": 9, "stroke-linecap": "round", transform: "rotate(-90 60 60)" });
    arc.style.strokeDasharray = String(c);
    arc.style.strokeDashoffset = String(c);
    s.appendChild(arc);
    var t1 = SG.svg("text", { "class": "g-num", x: 60, y: 62, "text-anchor": "middle" }); t1.textContent = score.toFixed(1) + "%";
    var t2 = SG.svg("text", { "class": "g-sub", x: 60, y: 80, "text-anchor": "middle" }); t2.textContent = "spam score";
    s.append(t1, t2);
    requestAnimationFrame(function () { requestAnimationFrame(function () { arc.style.strokeDashoffset = String(c * (1 - Math.min(100, Math.max(0, score)) / 100)); }); });
    return s;
  }

  function terms(list, kind) {
    var wrap = SG.el("div", "terms");
    if (!list.length) { wrap.appendChild(SG.el("span", "muted small", kind === "spam" ? "No spam-leaning words recognized." : "No safe-leaning words recognized.")); return wrap; }
    list.forEach(function (t) {
      var c = SG.el("span", "term term-" + kind);
      c.append(document.createTextNode(t.word + " "), SG.el("i", null, t.impact.toFixed(0) + "%"));
      c.title = "Share of the model's total word evidence (" + t.impact + "%)";
      wrap.appendChild(c);
    });
    return wrap;
  }

  var SIG_ICONS = { links: "link", phish: "key", money: "coin", urgency: "clock", phone: "phone", caps: "caps", exclaim: "bang" };

  function render(d) {
    empty.hidden = true; body.hidden = false; body.replaceChildren();
    var spam = d.prediction === "spam";
    card.setAttribute("data-state", spam ? "spam" : "ham");

    var top = SG.el("div", "verdict");
    top.appendChild(gauge(d.spam_score, spam ? "spam" : "ham"));
    var vt = SG.el("div", "verdict-text");
    var tag = SG.el("span", "verdict-tag");
    tag.append(SG.icon(spam ? "alert" : "shield"), document.createTextNode(spam ? "SPAM DETECTED" : "LOOKS SAFE"));
    vt.append(tag, SG.el("h3", "h3", spam ? "Potential spam" : "Likely a normal message"), SG.el("p", "muted", d.description));
    var risk = SG.el("span", "risk risk-" + d.risk, "Risk level: " + d.risk.charAt(0).toUpperCase() + d.risk.slice(1));
    vt.appendChild(risk);
    top.appendChild(vt);
    body.appendChild(top);

    var why = SG.el("div", "rsec");
    why.appendChild(SG.el("h4", "eyebrow-sm", "Why this verdict · model word evidence"));
    var g1 = SG.el("div", "tgroup"); g1.append(SG.el("span", "tlabel", "Pushes toward spam"), terms(d.spam_terms, "spam"));
    var g2 = SG.el("div", "tgroup"); g2.append(SG.el("span", "tlabel", "Pushes toward safe"), terms(d.ham_terms, "ham"));
    why.append(g1, g2);
    if (d.recognized_terms < 3) why.appendChild(SG.el("p", "warn small", "Only " + d.recognized_terms + " word(s) were recognized by the model, so this score is low-confidence."));
    body.appendChild(why);

    var chk = SG.el("div", "rsec");
    var flagged = d.signals.filter(function (s) { return s.found; }).length;
    chk.appendChild(SG.el("h4", "eyebrow-sm", "Suspicious content checklist · " + flagged + " of " + d.signals.length + " flagged"));
    var ul = SG.el("ul", "checks");
    d.signals.forEach(function (s) {
      var li = SG.el("li", "check " + (s.found ? "found sev-" + s.severity : "clear"));
      li.appendChild(SG.icon(s.found ? SIG_ICONS[s.key] || "alert" : "check", "check-ic"));
      var txt = SG.el("div", "check-txt");
      txt.append(SG.el("b", null, s.label), SG.el("span", "muted small", s.detail));
      li.appendChild(txt);
      if (s.found) li.appendChild(SG.el("span", "sev", s.severity));
      ul.appendChild(li);
    });
    chk.appendChild(ul);
    chk.appendChild(SG.el("p", "muted small", "Checklist items are rule-based hints shown next to the model verdict; they do not change the score."));
    body.appendChild(chk);

    var foot = SG.el("div", "rfoot");
    var a = SG.el("a", "link-sm", "View in history"); a.href = "/history"; a.appendChild(SG.icon("arrow"));
    foot.append(SG.el("span", "muted small", "Saved to your history · " + SG.fmtDateTime(d.created_at)), a);
    body.appendChild(foot);
  }

  form.addEventListener("submit", async function (e) {
    e.preventDefault();
    var s = subject.value.trim(), m = message.value.trim();
    if (!s && !m) { showError("Please enter an email subject or message."); message.focus(); return; }
    setBusy(true);
    try {
      var data = await SG.api("/api/predict", { method: "POST", body: { subject: s, message: m } });
      render(data);
      if (window.matchMedia("(max-width: 900px)").matches) card.scrollIntoView({ behavior: "smooth", block: "start" });
    } catch (err) {
      showError(err.message || "Could not connect to the server.");
    } finally { setBusy(false); }
  });
})();
