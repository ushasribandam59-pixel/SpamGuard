from pathlib import Path
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from flask import Flask, render_template, request, jsonify
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import (accuracy_score, precision_score, recall_score,
    f1_score, confusion_matrix, ConfusionMatrixDisplay, classification_report)

app = Flask(__name__)
BASE_DIR = Path(__file__).resolve().parent
STATIC_DIR = BASE_DIR / "static"

# Load and clean the SMS Spam Collection dataset
data = pd.read_csv(BASE_DIR / "spam.csv", encoding="latin-1")
data = data[["v1", "v2"]].copy()
data.columns = ["label", "message"]
data = data.dropna().drop_duplicates()
data["label"] = data["label"].astype(str).str.strip().str.lower()
data["message"] = data["message"].astype(str)
data = data[data["label"].isin(["ham", "spam"])]

X_train_text, X_test_text, y_train, y_test = train_test_split(
    data["message"], data["label"], test_size=0.20,
    random_state=42, stratify=data["label"])
vectorizer = TfidfVectorizer(max_features=3000)
X_train = vectorizer.fit_transform(X_train_text)
X_test = vectorizer.transform(X_test_text)
model = MultinomialNB()
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
accuracy = accuracy_score(y_test, y_pred)
precision = precision_score(y_test, y_pred, pos_label="spam", zero_division=0)
recall = recall_score(y_test, y_pred, pos_label="spam", zero_division=0)
f1 = f1_score(y_test, y_pred, pos_label="spam", zero_division=0)
cm = confusion_matrix(y_test, y_pred, labels=["ham", "spam"])
report = classification_report(y_test, y_pred, labels=["ham", "spam"],
    target_names=["Ham", "Spam"], output_dict=True, zero_division=0)

STATIC_DIR.mkdir(exist_ok=True)
fig, ax = plt.subplots(figsize=(6, 5))
ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=["Ham", "Spam"]).plot(
    ax=ax, cmap="Purples", values_format="d", colorbar=False)
ax.set_title("Naive Bayes Confusion Matrix")
fig.tight_layout()
fig.savefig(STATIC_DIR / "confusion_matrix.png", dpi=160)
plt.close(fig)

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/predict", methods=["POST"])
def predict():
    request_data = request.get_json(silent=True) or {}
    subject = str(request_data.get("subject", "")).strip()
    message = str(request_data.get("message", "")).strip()
    email_text = f"{subject} {message}".strip()
    if not email_text:
        return jsonify({"error": "Please enter an email subject or message."}), 400
    email_vector = vectorizer.transform([email_text])
    prediction = model.predict(email_vector)[0]
    probabilities = model.predict_proba(email_vector)[0]
    class_names = list(model.classes_)
    spam_score = float(probabilities[class_names.index("spam")] * 100)
    return jsonify({
        "prediction": prediction,
        "result": "SPAM" if prediction == "spam" else "HAM",
        "spam_score": round(spam_score, 2),
        "description": ("This message was classified as potentially unwanted or suspicious."
                        if prediction == "spam" else
                        "This message was classified as a normal message."),
    })

@app.route("/evaluation")
def evaluation():
    return render_template("evaluation.html",
        accuracy=round(accuracy * 100, 2), precision=round(precision * 100, 2),
        recall=round(recall * 100, 2), f1=round(f1 * 100, 2),
        total=len(y_test), train_total=len(y_train),
        ham_count=int((data["label"] == "ham").sum()),
        spam_count=int((data["label"] == "spam").sum()),
        ham_report=report["Ham"], spam_report=report["Spam"],
        matrix_url="/static/confusion_matrix.png")

if __name__ == "__main__":
    app.run(debug=True)
