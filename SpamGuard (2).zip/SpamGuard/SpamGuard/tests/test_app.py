"""Integration tests (standard library only).  Run:  python -m unittest discover -s tests -v"""
import os
import re
import sqlite3
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from app import create_app  # noqa: E402

SPAM = ("WINNER!! You have won a free £1000 gift voucher. Call now on 09061701461 "
        "or visit www.claim-prize.com to claim your cash prize. Urgent!")
HAM = "Hi, please submit your Python assignment before Monday. We will discuss it in class."


class Base(unittest.TestCase):
    rate_limit = False

    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.app = create_app({"DATABASE_PATH": os.path.join(self._tmp.name, "t.db"),
                               "TESTING": True, "RATELIMIT_ENABLED": self.rate_limit})
        self.c = self.app.test_client()

    def tearDown(self):
        self._tmp.cleanup()

    def token(self, client=None, path="/"):
        html = (client or self.c).get(path).get_data(as_text=True)
        return re.search(r'name="csrf-token" content="([^"]+)"', html).group(1)

    def post_json(self, url, payload, client=None, tok=None):
        client = client or self.c
        return client.post(url, json=payload, headers={"X-CSRF-Token": tok or self.token(client)})

    def signup(self, client=None, email="a@example.com", name="Ada Lovelace", pw="Sup3rSecret!"):
        client = client or self.c
        return client.post("/signup", data={"csrf_token": self.token(client, path="/signup"), "name": name,
                                            "email": email, "password": pw, "confirm": pw})

    def logout(self):
        self.c.post("/logout", data={"csrf_token": self.token()})


class PageTests(Base):
    def test_pages_render(self):
        for path in ["/", "/analyze", "/dashboard", "/history", "/evaluation", "/login", "/signup", "/api/health"]:
            with self.subTest(path=path):
                self.assertEqual(self.c.get(path).status_code, 200)

    def test_404_page(self):
        r = self.c.get("/definitely-missing")
        self.assertEqual(r.status_code, 404)
        self.assertIn(b"Page not found", r.data)

    def test_api_404_is_json(self):
        self.assertIn("error", self.c.get("/api/nope").get_json())

    def test_security_headers(self):
        r = self.c.get("/")
        self.assertEqual(r.headers["X-Frame-Options"], "DENY")
        self.assertIn("script-src 'self'", r.headers["Content-Security-Policy"])
        self.assertEqual(r.headers["X-Content-Type-Options"], "nosniff")


class PredictTests(Base):
    def test_spam_and_ham_are_classified_by_the_model(self):
        s = self.post_json("/api/predict", {"message": SPAM}).get_json()
        h = self.post_json("/api/predict", {"message": HAM}).get_json()
        self.assertEqual(s["prediction"], "spam")
        self.assertGreater(s["spam_score"], 50)
        self.assertEqual(h["prediction"], "ham")
        self.assertLess(h["spam_score"], 50)
        self.assertTrue(s["spam_terms"])
        self.assertTrue(all(t["direction"] == "spam" for t in s["spam_terms"]))
        found = {x["key"] for x in s["signals"] if x["found"]}
        self.assertTrue({"links", "money", "urgency"} <= found)
        self.assertFalse(any(x["found"] for x in h["signals"]))

    def test_legacy_predict_route_still_works(self):
        r = self.post_json("/predict", {"subject": "Free prize", "message": "claim now"})
        self.assertEqual(r.status_code, 200)
        self.assertIn(r.get_json()["result"], ("SPAM", "HAM"))

    def test_predict_requires_csrf(self):
        self.assertEqual(self.c.post("/api/predict", json={"message": "hi"}).status_code, 403)

    def test_predict_validation(self):
        cases = [{}, {"message": "   "}, {"message": 123}, {"message": "x" * 5001},
                 {"subject": "s" * 201, "message": "x"}, [1, 2]]
        for payload in cases:
            with self.subTest(payload=str(payload)[:30]):
                self.assertEqual(self.post_json("/api/predict", payload).status_code, 400)

    def test_predict_rejects_non_json(self):
        r = self.c.post("/api/predict", data="hello", headers={"X-CSRF-Token": self.token()})
        self.assertEqual(r.status_code, 400)
        self.assertIn("error", r.get_json())


class HistoryTests(Base):
    def test_history_and_stats_reflect_real_scans(self):
        self.assertEqual(self.c.get("/api/stats").get_json()["total"], 0)
        tok = self.token()
        self.post_json("/api/predict", {"message": SPAM}, tok=tok)
        self.post_json("/api/predict", {"message": HAM}, tok=tok)
        st = self.c.get("/api/stats").get_json()
        self.assertEqual((st["total"], st["spam"], st["ham"]), (2, 1, 1))
        self.assertEqual(st["spam_rate"], 50.0)
        self.assertEqual(sum(b["count"] for b in st["score_buckets"]), 2)
        self.assertEqual(sum(d["total"] for d in st["timeline"]), 2)
        self.assertEqual(len(st["timeline"]), 14)
        hist = self.c.get("/api/history").get_json()
        self.assertEqual(hist["total"], 2)
        self.assertEqual(hist["items"][0]["label"], "ham")  # newest first
        self.assertEqual(self.c.get("/api/history?label=spam").get_json()["total"], 1)
        self.assertEqual(self.c.get("/api/history?q=python").get_json()["total"], 1)
        self.assertEqual(self.c.get("/api/history?q=%25").get_json()["total"], 0)  # LIKE wildcard escaped

    def test_history_is_private_between_visitors(self):
        self.post_json("/api/predict", {"message": SPAM})
        other = self.app.test_client()
        self.assertEqual(other.get("/api/history").get_json()["total"], 0)
        r = other.delete("/api/history/1", headers={"X-CSRF-Token": self.token(other)})
        self.assertEqual(r.status_code, 404)

    def test_delete_and_clear(self):
        tok = self.token()
        a = self.post_json("/api/predict", {"message": SPAM}, tok=tok).get_json()["id"]
        self.post_json("/api/predict", {"message": HAM}, tok=tok)
        self.assertEqual(self.c.delete(f"/api/history/{a}", headers={"X-CSRF-Token": tok}).status_code, 200)
        self.assertEqual(self.c.get("/api/history").get_json()["total"], 1)
        self.assertEqual(self.c.delete("/api/history", headers={"X-CSRF-Token": tok}).get_json()["deleted"], 1)
        self.assertEqual(self.c.delete("/api/history").status_code, 403)  # CSRF required

    def test_csv_export_neutralises_formulas(self):
        self.post_json("/api/predict", {"subject": '=HYPERLINK("http://x")', "message": "win cash now"})
        text = self.c.get("/history/export.csv").get_data(as_text=True)
        self.assertIn("'=HYPERLINK", text)
        self.assertTrue(text.startswith("scanned_at_utc"))


class AuthTests(Base):
    def test_signup_login_logout_flow(self):
        r = self.signup()
        self.assertEqual(r.status_code, 302)
        self.assertTrue(r.headers["Location"].endswith("/dashboard"))
        self.assertIn(b"Ada", self.c.get("/dashboard").data)
        self.logout()
        self.assertIn(b"Sign up", self.c.get("/").data)
        bad = self.c.post("/login", data={"csrf_token": self.token(path="/login"),
                                          "email": "a@example.com", "password": "wrong"})
        self.assertEqual(bad.status_code, 401)
        self.assertIn(b"Incorrect email or password", bad.data)
        ok = self.c.post("/login", data={"csrf_token": self.token(path="/login"),
                                         "email": "a@example.com", "password": "Sup3rSecret!"})
        self.assertEqual(ok.status_code, 302)

    def test_password_is_hashed_and_duplicates_rejected(self):
        self.signup()
        con = sqlite3.connect(self.app.config["DATABASE_PATH"])
        stored = con.execute("SELECT password_hash FROM users").fetchone()[0]
        con.close()
        self.assertNotIn("Sup3rSecret!", stored)
        self.assertTrue(stored.startswith(("scrypt:", "pbkdf2:")))
        self.assertEqual(self.signup(self.app.test_client()).status_code, 400)

    def test_signup_validation(self):
        for kw in [{"pw": "short1!"}, {"pw": "12345678"}, {"email": "not-an-email"}, {"name": "A"}]:
            with self.subTest(kw=kw):
                self.assertEqual(self.signup(self.app.test_client(), **kw).status_code, 400)

    def test_login_open_redirect_blocked(self):
        self.signup()
        self.logout()
        r = self.c.post("/login", data={"csrf_token": self.token(path="/login"), "email": "a@example.com",
                                        "password": "Sup3rSecret!", "next": "https://evil.example"})
        self.assertTrue(r.headers["Location"].endswith("/dashboard"))

    def test_forms_require_csrf(self):
        self.assertEqual(self.c.post("/login", data={"email": "a@b.co", "password": "x"}).status_code, 400)
        self.assertEqual(self.c.post("/signup", data={"name": "x"}).status_code, 400)
        self.assertEqual(self.c.post("/logout").status_code, 400)

    def test_guest_scans_move_to_account_on_signup(self):
        self.post_json("/api/predict", {"message": SPAM})
        self.signup()
        self.assertEqual(self.c.get("/api/history").get_json()["total"], 1)
        self.assertEqual(self.app.test_client().get("/api/history").get_json()["total"], 0)


class RateLimitTests(Base):
    rate_limit = True

    def test_login_is_rate_limited(self):
        codes = [self.c.post("/login", data={"csrf_token": self.token(path="/login"),
                                             "email": "x@y.co", "password": "bad"}).status_code
                 for _ in range(12)]
        self.assertIn(429, codes)


if __name__ == "__main__":
    unittest.main()
